package kerosene.v05.contracts;

public interface TOTPKeyGenerate {
    String keyGenerator();;

}
